// modules/auth/auth.model.js
// Not used directly. Authentication uses user.model.js for user data. 